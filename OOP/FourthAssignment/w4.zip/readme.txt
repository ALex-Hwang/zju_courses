The format of the date is year-mm-dd.
The parameters should be given when you execute the program.
Due to the relative directory problem in mac os, before you run the program, you need to change the file directory in dairy.cpp.
